CKEDITOR.plugins.setLang('imagecrop', 'en', {
    cropTab: 'Crop Image',
    title: 'Crop Image',
    btnUpload: 'Send it to the Server',
    wrongImageType: 'Please choose an image file.'
});
